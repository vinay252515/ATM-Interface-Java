import java.io.*;
import java.util.*;

public class ATM {
    private User user;
    private List<String> transactionHistory;

    public ATM(User user) {
        this.user = user;
        this.transactionHistory = new ArrayList<>();
    }

    // Deposit
    public void deposit(double amount) {
        user.setBalance(user.getBalance() + amount);
        transactionHistory.add("Deposit: +" + amount);
        System.out.println("Deposit successful. New balance: " + user.getBalance());
    }

    // Withdraw
    public void withdraw(double amount) {
        if (amount > user.getBalance()) {
            System.out.println("Insufficient balance!");
        } else {
            user.setBalance(user.getBalance() - amount);
            transactionHistory.add("Withdrawal: -" + amount);
            System.out.println("Withdrawal successful. New balance: " + user.getBalance());
        }
    }

    // Check Balance
    public void checkBalance() {
        System.out.println("Current balance: " + user.getBalance());
    }

    // Print Transaction History
    public void printTransactionHistory() {
        System.out.println("\n--- Transaction History ---");
        for (String transaction : transactionHistory) {
            System.out.println(transaction);
        }
    }
}