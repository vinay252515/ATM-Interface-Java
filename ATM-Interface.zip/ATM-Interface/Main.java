import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Initialize a user (hardcoded for simplicity)
        User user = new User("user123", "1234", 1000.0);
        ATM atm = new ATM(user);

        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the ATM!");

        // Authentication
        System.out.print("Enter User ID: ");
        String userId = scanner.nextLine();
        System.out.print("Enter PIN: ");
        String pin = scanner.nextLine();

        if (!userId.equals(user.getUserId()) || !pin.equals(user.getPin())) {
            System.out.println("Invalid credentials!");
            return;
        }

        // ATM Menu
        while (true) {
            System.out.println("\n1. Deposit");
            System.out.println("2. Withdraw");
            System.out.println("3. Check Balance");
            System.out.println("4. Transaction History");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    System.out.print("Enter deposit amount: ");
                    double depositAmount = scanner.nextDouble();
                    atm.deposit(depositAmount);
                    break;
                case 2:
                    System.out.print("Enter withdrawal amount: ");
                    double withdrawAmount = scanner.nextDouble();
                    atm.withdraw(withdrawAmount);
                    break;
                case 3:
                    atm.checkBalance();
                    break;
                case 4:
                    atm.printTransactionHistory();
                    break;
                case 5:
                    System.out.println("Thank you for using the ATM. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid option!");
            }
        }
    }
}