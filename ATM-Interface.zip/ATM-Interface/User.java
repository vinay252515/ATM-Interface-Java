public class User {
    private String userId;
    private String pin;
    private double balance;

    // Constructor
    public User(String userId, String pin, double balance) {
        this.userId = userId;
        this.pin = pin;
        this.balance = balance;
    }

    // Getters and Setters
    public String getUserId() { return userId; }
    public String getPin() { return pin; }
    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }
}